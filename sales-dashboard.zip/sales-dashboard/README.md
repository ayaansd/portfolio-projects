
# Sales Dashboard — SQL Star Schema + Power BI

💹 **Goal:** Build a **star schema** (fact_sales + dimensions) and connect to **Power BI** (or Tableau) to analyze revenue, product performance, and customer trends.

## 🚩 What It Solves
- ❌ Raw sales data is messy, hard to query directly, and not optimized for BI.
- ✅ This project transforms sales data into a **star schema**, enabling **fast, intuitive analysis** in Power BI with reusable metrics (revenue, top products, top customers).

## 🛠️ Tools & Tech
- **SQL** — star schema design & transformations  
- **Power BI / Tableau** — interactive dashboards  
- **CSV Data** — synthetic sample of customers, products, sales  

## 📂 Repository Structure
```
sales-dashboard/
├─ README.md
├─ data/
│  ├─ customers.csv
│  ├─ products.csv
│  └─ sales.csv
└─ sql/
   └─ model.sql       # schema creation + sample queries
```

## 🔢 Dataset
- **customers.csv** → 100 synthetic customers  
- **products.csv** → 50 synthetic products across 5 categories  
- **sales.csv** → ~1,000 sales transactions (customer_id, product_id, qty, price, date)  

## 🚀 Quickstart
1. Import CSVs into your database (e.g., DuckDB, Postgres, BigQuery).  
2. Run SQL in `sql/model.sql` to create **fact + dimensions**.  
3. Connect Power BI to the database or CSVs.  
4. Build dashboards with provided metrics.  

## 📊 Suggested Dashboards (Power BI)
- **Revenue Trends** → line chart by month/year  
- **Top Products** → bar chart by revenue or qty  
- **Top Customers** → bar chart by spend  
- **Category Mix** → stacked bar/pie of product categories  
- **KPIs** → total revenue, avg order value (AOV), customer count  

## 🔜 Roadmap
- [ ] Add **dim_date** with fiscal calendar  
- [ ] Incremental refresh pipelines (dbt, Airflow)  
- [ ] DAX measures (churn rate, retention cohorts)  
- [ ] Deploy with **Power BI Service** or **Tableau Server**

## 📜 License
MIT
