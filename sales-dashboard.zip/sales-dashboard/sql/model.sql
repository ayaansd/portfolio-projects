
-- Example star schema creation

-- dim_customer
create table dim_customer as
select distinct customer_id, customer_name from customers;

-- dim_product
create table dim_product as
select distinct product_id, product_name, category from products;

-- fact_sales
create table fact_sales as
select s.order_id, s.order_date, s.customer_id, s.product_id,
       s.qty, s.price, (s.qty * s.price) as revenue
from sales s;
