
import pandas as pd, numpy as np, matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from pathlib import Path

df = pd.read_csv("data/transactions.csv", parse_dates=["order_date"])
now = df["order_date"].max() + pd.Timedelta(days=1)
rfm = df.groupby("customer_id").agg(
    recency=("order_date", lambda s: (now - s.max()).days),
    frequency=("order_id", "nunique"),
    monetary=("amount", "sum"),
).reset_index()

X = rfm[["recency","frequency","monetary"]].values
X = StandardScaler().fit_transform(X)

# elbow
inertias = []
for k in range(2,8):
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X)
    inertias.append(km.inertia_)
Path("charts").mkdir(exist_ok=True)
plt.figure()
plt.plot(range(2,8), inertias, marker="o")
plt.title("Elbow")
plt.xlabel("k")
plt.ylabel("Inertia")
plt.savefig("charts/elbow.png", bbox_inches="tight")

# choose k=4
km = KMeans(n_clusters=4, n_init=10, random_state=42).fit(X)
rfm["cluster"] = km.labels_
Path("output").mkdir(exist_ok=True)
rfm.to_csv("output/segments.csv", index=False)
print("✅ saved output/segments.csv and charts/elbow.png")
