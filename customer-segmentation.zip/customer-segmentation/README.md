
# Customer Segmentation & Purchase Analysis — RFM + KMeans (Advanced)

📈 **Goal:** Segment 100K+ customers using **RFM metrics** (Recency, Frequency, Monetary) and **KMeans**, then visualize **CLV** and behavior in **Power BI** for targeted marketing.

## 🛠️ Tools & Tech
- **Python**: Pandas, Scikit-learn, Matplotlib
- **Segmentation**: RFM scoring + KMeans clustering
- **BI**: Power BI / Tableau (CLV segments, behavior dashboards)

## 📂 Project Structure
```
customer-segmentation/
├─ README.md
├─ requirements.txt          # pandas, scikit-learn, matplotlib
├─ data/
│  └─ transactions.csv       # synthetic transactions (demo)
├─ charts/
│  └─ elbow.png              # created on run
├─ output/
│  └─ segments.csv           # created on run
└─ rfm_kmeans.py             # RFM + KMeans pipeline
```

## 🚀 Quickstart
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python rfm_kmeans.py
```

**Outputs**
- `charts/elbow.png` — elbow method to choose k  
- `output/segments.csv` — `customer_id, recency, frequency, monetary, cluster`

## 🧠 Methodology
1. **RFM Features**
   - **Recency**: days since last purchase  
   - **Frequency**: #orders  
   - **Monetary**: total spend  
2. **Scaling** → Standardize features for clustering  
3. **Modeling** → KMeans (default **k=4** after elbow search)  
4. **Evaluation** → Inspect cluster sizes & profiles  
5. **Activation** → Export segments for **Power BI / Tableau** dashboards

## 📊 Suggested Dashboards (Power BI)
- Segment mix (% of customers by cluster)  
- CLV by segment (avg monetary)  
- Repeat rate by segment (frequency)  
- Recency distribution (win-back targeting)

## 🔬 Next Steps
- Add **PCA** for cluster visualization  
- Auto-select **k** via silhouette score  
- Train **uplift models** for offer targeting  
- Build a **dbt** model + BI on warehouse data

## 📜 License
MIT
