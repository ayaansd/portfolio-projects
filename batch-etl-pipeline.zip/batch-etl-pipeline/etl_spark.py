
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, countDistinct, to_date

spark = SparkSession.builder.appName("batch-etl").getOrCreate()
df = spark.read.option("header", True).csv("data/logs.csv")
clean = df.dropna(subset=["user_id","event_time"]).dropDuplicates(["user_id","event_time"])
clean = clean.withColumn("date", to_date(col("event_time")))
daily = clean.groupBy("date").agg(countDistinct("user_id").alias("daus"))
daily.orderBy("date").show(10, truncate=False)
daily.write.mode("overwrite").parquet("warehouse/daily_metrics")
print("✅ Wrote warehouse/daily_metrics")
