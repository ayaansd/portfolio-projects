
# Batch ETL Pipeline — PySpark + Hive

**Goal:** Ingest 5M+ log records, clean/dedup, aggregate facts, and store in **Hive** tables for downstream BI.

## Quickstart (local dev)
```bash
python etl_spark.py  # requires pyspark (local mode)
```

## Steps
1) Read raw logs (CSV/JSON).
2) Clean & deduplicate.
3) Aggregate daily/weekly metrics.
4) Write to Hive tables (parquet/ORC).

