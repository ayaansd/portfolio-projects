
import pandas as pd, json, joblib, os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, roc_auc_score
from xgboost import XGBClassifier

df = pd.read_csv("data/churn.csv")
X = df.drop(columns=["churn"])
y = df["churn"]

pre = ColumnTransformer([("cat", OneHotEncoder(handle_unknown="ignore"), ["contract"])], remainder="passthrough")
model = Pipeline([("prep", pre), ("clf", XGBClassifier(n_estimators=200, max_depth=4, learning_rate=0.1, subsample=0.9, colsample_bytree=0.9, random_state=42))])

Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
model.fit(Xtr, ytr)
pred = model.predict(Xte)
proba = model.predict_proba(Xte)[:,1]

acc = accuracy_score(yte, pred)
auc = roc_auc_score(yte, proba)

os.makedirs("model", exist_ok=True)
joblib.dump(model, "model/model.pkl")

with open("metrics.json","w") as f:
    json.dump({"accuracy": round(acc,4), "auc": round(auc,4)}, f)

print("✅ metrics:", {"accuracy": round(acc,4), "auc": round(auc,4)})
