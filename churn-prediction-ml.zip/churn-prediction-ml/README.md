
# Churn Prediction ML — XGBoost + SHAP (Advanced)

🧠 **Goal:** Predict subscription churn with ML models, providing **explainability** and **business insights**.

---

## 🚩 What It Solves
- ❌ Subscription businesses lose revenue due to unanticipated churn.
- ✅ This model predicts churn risk, enabling **proactive retention strategies** and **personalized offers**.

---

## 🛠️ Tools & Tech
- **Python**: Pandas, Scikit-learn, XGBoost
- **Explainability**: SHAP (optional)
- **Experiment Tracking**: MLflow (optional)

---

## 📂 Repository Structure
```
churn-prediction-ml/
├─ README.md
├─ requirements.txt
├─ data/
│  └─ churn.csv           # synthetic dataset
├─ model/
│  └─ model.pkl           # trained model (created on run)
├─ metrics.json           # accuracy & AUC (created on run)
├─ train.py               # training pipeline
└─ predict.py             # inference script
```

---

## 🚀 Quickstart
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Train the model
python train.py

# Predict churn risk for a sample user
python predict.py --tenure 8 --monthly_charges 79.0 --contract TwoYear --support_tickets 2
```

**Outputs**
- `model/model.pkl` → trained model  
- `metrics.json` → accuracy & AUC metrics  
- Console prediction: churn label + probability  

---

## 🧠 Methodology
1. **Data** → synthetic telecom subscription data (tenure, monthly charges, contract type, support tickets).  
2. **Preprocessing** → one-hot encoding for categorical vars.  
3. **Modeling** → XGBoost classifier (200 trees, depth=4).  
4. **Evaluation** → Accuracy + ROC-AUC.  
5. **Explainability** → SHAP values to interpret feature impact.  

---

## 📊 Example Insights
- Customers with **month-to-month contracts** and **high support tickets** churn more.  
- Long-tenure users with **two-year contracts** churn less.  
- High monthly charges without added value increase churn risk.  

---

## 🔜 Roadmap
- [ ] Add SHAP explainability plots  
- [ ] Log experiments with MLflow  
- [ ] Deploy model as FastAPI service  
- [ ] Create Power BI dashboard for churn segments  

---

## 📜 License
MIT
