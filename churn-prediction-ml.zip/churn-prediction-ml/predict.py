
import argparse, joblib, pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("--tenure", type=int, required=True)
ap.add_argument("--monthly_charges", type=float, required=True)
ap.add_argument("--contract", type=str, default="MonthToMonth")
ap.add_argument("--support_tickets", type=int, default=0)
args = ap.parse_args()

m = joblib.load("model/model.pkl")
x = pd.DataFrame([vars(args)])
y = m.predict(x)[0]
p = m.predict_proba(x)[0,1]
print({"churn_pred": int(y), "prob": float(round(p,4))})
