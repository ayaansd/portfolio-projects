
# Market Research Dashboard — Sentiment + Trends

📊 **Goal:** Analyze product reviews, extract keywords & sentiment, and build BI-ready datasets and charts to guide business strategy.

---

## 🚩 What It Solves
- ❌ Companies often lack structured insights from raw customer reviews.
- ✅ This pipeline converts unstructured feedback into **sentiment metrics**, **keyword frequency**, and **regional trends** that can feed **Power BI dashboards**.

---

## 🛠️ Tools & Tech
- **Python**: Pandas (ETL), Matplotlib (charts)
- **NLP (basic)**: keyword frequency + sentiment proxy via ratings
- **Power BI / Tableau**: dashboards built on cleaned datasets

---

## 📂 Repository Structure
```
market-research-dashboard/
├─ README.md
├─ requirements.txt
├─ data/
│  └─ reviews.csv           # synthetic product reviews
├─ etl/
│  └─ prepare.py            # ETL script: clean + keyword extraction
├─ charts/
│  └─ word_freq.png         # top keywords chart (created on run)
└─ data/clean_reviews.csv   # BI-ready dataset (created on run)
```

---

## 🚀 Quickstart
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python etl/prepare.py
```

**Outputs**
- `data/clean_reviews.csv` — BI-ready dataset with sentiment flag  
- `charts/word_freq.png` — bar chart of most frequent words  

---

## 🧠 Methodology
1. **Ingest** → raw CSV of reviews (`review_id, region, rating, review_text`)  
2. **Sentiment Proxy** → positive if rating ≥4, else negative  
3. **Keyword Extraction** → frequency count of tokens  
4. **Visualization** → top words bar chart  
5. **BI Export** → save enriched reviews dataset for Power BI

---

## 📊 Suggested Dashboards (Power BI)
- **Sentiment by Region** → % positive vs negative  
- **Top Complaints/Praise** → word frequency filtered by sentiment  
- **Revenue + Sentiment Overlay** → join reviews with sales data  
- **Trend Analysis** → sentiment over time

---

## 🔜 Roadmap
- [ ] Add advanced NLP (VADER, transformers)  
- [ ] Topic modeling (LDA) for themes  
- [ ] Deploy pipeline with Airflow  
- [ ] Auto-refresh Power BI dashboards  

---

## 📜 License
MIT
