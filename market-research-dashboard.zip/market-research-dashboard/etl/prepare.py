
import pandas as pd, matplotlib.pyplot as plt
from collections import Counter
from pathlib import Path

df = pd.read_csv("data/reviews.csv")
df['is_positive'] = (df['rating']>=4).astype(int)

words = []
for t in df['review_text'].astype(str).str.lower():
    words.extend([w for w in t.split() if w.isalpha()])
cnt = Counter(words)
top = pd.DataFrame(cnt.most_common(20), columns=["word","freq"])

Path("charts").mkdir(exist_ok=True)
plt.figure(figsize=(8,4))
top.plot(kind="bar", x="word", y="freq", legend=False)
plt.title("Top Words in Reviews")
plt.tight_layout()
plt.savefig("charts/word_freq.png")

df.to_csv("data/clean_reviews.csv", index=False)
print("✅ Wrote data/clean_reviews.csv and charts/word_freq.png")
