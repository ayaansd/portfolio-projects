
import pandas as pd, matplotlib.pyplot as plt
from pathlib import Path

df = pd.read_csv("data/survey.csv")
promoters = (df['rating']>=9).sum()
detractors = (df['rating']<=6).sum()
n = len(df)
nps = ((promoters - detractors)/n)*100

# chart
Path("charts").mkdir(exist_ok=True)
plt.figure()
df['rating'].hist(bins=11)
plt.title("Rating Distribution (0-10)")
plt.xlabel("Rating")
plt.ylabel("Count")
plt.tight_layout()
plt.savefig("charts/ratings.png", bbox_inches="tight")

# summary
summary = pd.DataFrame([{
    "responses": int(n),
    "promoters": int(promoters),
    "detractors": int(detractors),
    "nps": round(nps,2)
}])
Path("output").mkdir(parents=True, exist_ok=True)
summary.to_csv("output/summary.csv", index=False)
print("✅ Wrote charts/ratings.png and output/summary.csv")
