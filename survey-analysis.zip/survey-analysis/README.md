
# Survey Analysis — Python EDA + Sentiment

📋 **Goal:** Analyze survey responses, compute **NPS**, and visualize basic sentiment/keyword trends for product feedback.

## 🛠️ Tools & Tech
- **Python**: Pandas, Matplotlib
- **Outputs**: NPS summary CSV, rating distribution chart, BI‑ready cleaned data

## 📂 Project Structure
```
survey-analysis/
├─ README.md
├─ requirements.txt          # pandas, matplotlib
├─ data/
│  └─ survey.csv             # synthetic survey responses
├─ charts/
│  └─ ratings.png            # created on run
├─ output/
│  └─ summary.csv            # created on run
└─ analyze.py                # EDA + NPS + simple keyword frequency
```

## 🚀 Quickstart
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python analyze.py
```

**Outputs**
- `charts/ratings.png` — distribution of ratings (0–10)  
- `output/summary.csv` — NPS and counts (promoters, passives, detractors)

## 📊 Notes
- Replace `data/survey.csv` with your own survey data (same columns), or adapt `analyze.py`.
- Extend with word clouds, bigrams, or sentiment libraries if needed.

## 📜 License
MIT
