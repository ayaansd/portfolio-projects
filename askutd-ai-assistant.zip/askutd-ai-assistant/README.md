# AskUTD – Full-Stack MVP (FastAPI + React-CDN)

This is a **zip-ready, end-to-end** version of AskUTD: a lightweight RAG chatbot for UTD resources.

## Structure
```
askutd-ai-assistant/
├─ backend/          # FastAPI app, embeddings, FAISS index
├─ frontend/         # Minimal React (via CDN) UI that talks to backend
├─ scripts/          # Helper scripts
├─ LICENSE
└─ .gitignore
```

## Quickstart

### 1) Backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env  # add your OpenAI key
python embed_docs.py  # build FAISS from /backend/data/*.txt
uvicorn app:app --reload --port 8000
```

### 2) Frontend
Open `frontend/index.html` directly in your browser **or** serve it (recommended) with a simple server:
```bash
# From the repo root:
python -m http.server 5173
# Visit http://localhost:5173/frontend
```
> The frontend expects backend at `http://localhost:8000` (configurable at the top of `frontend/app.js`).

### 3) Smoke Test (proof it works)
```bash
cd backend
pytest -q
# or
python smoke_test.py
```

### Notes
- Replace the sample `.txt` files in `/backend/data` with curated content from UTD websites and re-run `python embed_docs.py`.
- The **/backend** API has: `GET /health`, `POST /embed` (rebuild index), `POST /ask` (JSON: { "query": "..." }).
- CORS is enabled for `http://localhost:5173` by default.
