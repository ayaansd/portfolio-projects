# Frontend (React via CDN)

Open `index.html` in a browser or serve from a simple web server.

- Configurable backend URL at the top of `app.js` (default `http://localhost:8000`).
- Minimal UI: input + button + render answer + sources.
