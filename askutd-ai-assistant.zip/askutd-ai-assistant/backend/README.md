# Backend (FastAPI)

## Endpoints
- `GET /health` → `{ "status": "ok" }`
- `POST /embed` → rebuild FAISS from `/backend/data/*.txt`
- `POST /ask` body: `{ "query": "..." }` → `{ "answer": "...", "sources": ["file1.txt", ...] }`

## Run
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python embed_docs.py
uvicorn app:app --reload --port 8000
```
