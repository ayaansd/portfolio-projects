
# Cloud Job ETL — GCP BigQuery + Airflow (Advanced)

**Goal:** Ingest 200K+ job postings into **BigQuery**, run **40+ SQL transforms**, and serve **Power BI dashboards**.

## Architecture
- **Ingest**: Python operator downloads CSV to GCS.
- **Load**: BigQueryLoadJobOperator → raw table.
- **Transform**: dbt-style **SQL scripts** in `sql/transformations/` executed via BigQuery.
- **Serve**: Power BI connects to BQ (DirectQuery or scheduled refresh).

## Quickstart (local dev mock)
```bash
python dags/dev_local_runner.py   # runs the extract->transform->load steps locally against duckdb
```

## Files
- `dags/job_etl.py` – Airflow DAG (GCP operators).
- `dags/dev_local_runner.py` – local runner using DuckDB (no GCP needed for demo).
- `sql/transformations/*.sql` – 10 example transforms (expand to 40+).
- `data/sample_jobs.csv` – synthetic dataset (~1k rows).
